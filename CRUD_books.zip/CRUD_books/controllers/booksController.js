const { validationResult } = require('express-validator');
const booksService = require('../services/booksService');

const getAllBooks = async (req, res) => {
  try{
    const books = await booksService.getAllBooks();
    res.send(books);

  }catch(err){
    res.status(500).send(err)
  }
  
};

const getBookById = async (req, res) => {
  try{
    const book = await booksService.getBookById(req.params.id);
    res.send(book);
  }catch(err){
    res.status(err.statusCode).send({errorCode : err.errorCode , message : err.message})
  }
 
};

const createBook = async (req, res) => {
  const errors = validationResult(req)
  if(!errors.isEmpty()){
    return res.status(400).send(errors.errors[0].msg)
  }
  try{
    const bookData = req.body;
    const book = await booksService.createBook(bookData);
    res.send({message : "Book added successfully"});
  }catch(err){
    res.status(500).send(err)
  }
};

const updateBook = async (req, res) => {
  const errors = validationResult(req)
  if(!errors.isEmpty()){
    return res.status(400).send(errors.errors[0].msg)
  }
  try{
    await booksService.getBookById(req.params.id)
    const bookData = req.body;
    const book = await booksService.updateBook(req.params.id, bookData);
    res.send({message : "Book updated successfully"});

  }catch(err){
    res.status(err.statusCode).send({errorCode : err.errorCode , message : err.message})
  }
};

const deleteBook = async (req, res) => {
  try{
    await booksService.getBookById(req.params.id)
    await booksService.deleteBook(req.params.id);
    res.send({ message: 'Book deleted successfully' });

  }catch(err){
    res.status(err.statusCode).send({errorCode : err.errorCode , message : err.message})
  }
};

module.exports = {
  getAllBooks,
  getBookById,
  createBook,
  updateBook,
  deleteBook,
};
