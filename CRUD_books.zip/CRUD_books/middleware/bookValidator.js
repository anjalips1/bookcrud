const {body,param} = require('express-validator')
const bookValidator =(validationType)=>{
    switch(validationType){
        case 'addBook':
            return[
                body('title')
                    .trim()
                    .notEmpty()
                    .withMessage({errorCode: 1000 ,message : "Title is required"}),


                body('author')
                    .trim()
                    .notEmpty()
                    .withMessage({ errorCode:1002 , message : "Author is required" }),

                body('summary')
                    .trim()
                    .notEmpty()
                    .withMessage({ errorCode:1003 , message : "Summary is required" })

            ]

    }
}



module.exports = {bookValidator}