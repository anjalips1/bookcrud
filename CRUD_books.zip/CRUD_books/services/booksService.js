const Book = require('../models/books');
const mongoose = require('mongoose');


const getAllBooks = async () => {
  return Book.find();
};


const createBook = async (bookData) => {
  return Book.create(bookData);
};

const getBookById = async (id) => {
  if (!mongoose.Types.ObjectId.isValid(id)) {
    const customError = new Error('Invalid ObjectId format');
    customError.errorCode = 1004; 
    customError.statusCode = 400; 
    throw customError;
  }

  const book = await Book.findById(id);

  if (!book) {
    const notFoundError = new Error('Book not found');
    notFoundError.errorCode = 1005; 
    notFoundError.statusCode = 404;
    throw notFoundError;
  }
  return book;
};

const updateBook = async (id, bookData) => {
  return Book.findByIdAndUpdate(id, bookData, { new: true });
};

const deleteBook = async (id) => {
  return Book.findByIdAndDelete(id);
};

module.exports = {
  getAllBooks,
  getBookById,
  createBook,
  updateBook,
  deleteBook,
};
